function saludo(nombre){
    alert("HOLA..."+nombre +"&nbsp"+"\n"+"VAMOS A APRENDER LOS 5 PROGRAMAS FANTASTICOS:..."+"\n"+"HTML-CSS-JS–zPHP-MYSQL");
  }
